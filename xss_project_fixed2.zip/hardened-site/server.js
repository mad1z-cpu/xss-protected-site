const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const helmet = require('helmet');
const xss = require('xss'); // sanitizer for server-side
const app = express();
const PORT = process.env.PORT || 3002;

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      objectSrc: ["'none'"],
      upgradeInsecureRequests: []
    }
  }
}));

const comments = [];

app.get('/', (req, res) => {
  const q = req.query.q || '';
  const safeQ = xss(q);
  res.render('index', { q: safeQ, comments });
});

app.post('/comment', (req, res) => {
  const name = xss(req.body.name || 'anon');
  const text = xss(req.body.text || '');
  comments.push({ name, text, date: new Date().toISOString() });
  res.redirect('./');
});

app.get('/dom', (req, res) => {
  res.render('dom');
});

app.listen(PORT, () => {
  console.log('Hardened app listening on port', PORT);
});
