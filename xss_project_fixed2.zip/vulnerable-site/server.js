const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3001;

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));

// In-memory "comments" to demonstrate stored XSS
const comments = [];

// Home -> shows reflected XSS demo
app.get('/', (req, res) => {
  // reflected: echo q parameter directly into page
  const q = req.query.q || '';
  res.render('index', { q, comments });
});

// Endpoint to add comment (stored XSS demo)
app.post('/comment', (req, res) => {
  const name = req.body.name || 'anon';
  const text = req.body.text || '';
  // we store without sanitization -> stored XSS vulnerable
  comments.push({ name, text, date: new Date().toISOString() });
  // relative redirect so proxy prefixes work correctly
  res.redirect('./');
});

// Simple page to demonstrate DOM-based XSS
app.get('/dom', (req, res) => {
  res.render('dom');
});

app.listen(PORT, () => {
  console.log('Vulnerable app listening on port', PORT);
});
