XSS Project (fixed)
- vulnerable-site: intentionally vulnerable, Russian UI, relative form actions, DOM demo decodes hash
- hardened-site: sanitized, uses helmet and xss, safe DOM handling
- nginx routes: /vuln/ -> vulnerable, /safe/ -> hardened
- docker-compose: run `docker-compose up --build` and open http://localhost:8080/vuln/ and /safe/

Notes:
- Stored comments are in-memory (ephemeral). To persist, mount a volume or add a DB.
- Only use in local/lab environment.
